# Kindred — Flutter starter

This is the first UI foundation for the new Kindred app.

## Included
- Blue and green visual theme
- Bottom navigation: Chats, Status, Sites, Calls
- Starter screens for each section

## Important
This is a UI prototype, not a complete messaging service yet. Login, real-time messages,
media uploads, push notifications, voice/video calling, moderation, and security still
need to be implemented and tested.

## Run on a computer
1. Install Flutter SDK and Android Studio.
2. Create a Flutter project: `flutter create kindred`
3. Replace `kindred/lib/main.dart` with this project's `lib/main.dart`.
4. Run `flutter pub get` then `flutter run`.

No external packages are required for this starter.
