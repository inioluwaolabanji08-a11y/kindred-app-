import 'package:flutter/material.dart';

void main() => runApp(const KindredApp());

const kindredBlue = Color(0xFF1769D2);
const kindredGreen = Color(0xFF119B72);
const kindredBackground = Color(0xFFF5F8FC);

class KindredApp extends StatelessWidget {
  const KindredApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Kindred',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: kindredBackground,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kindredBlue,
          primary: kindredBlue,
          secondary: kindredGreen,
          surface: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF152238),
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const KindredHome(),
    );
  }
}

class KindredHome extends StatefulWidget {
  const KindredHome({super.key});

  @override
  State<KindredHome> createState() => _KindredHomeState();
}

class _KindredHomeState extends State<KindredHome> {
  int selectedTab = 0;

  final pages = const [
    ChatsPage(),
    StatusPage(),
    SitesPage(),
    CallsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [kindredBlue, kindredGreen],
                ),
                borderRadius: BorderRadius.circular(11),
              ),
              child: const Icon(Icons.people_alt_rounded,
                  color: Colors.white, size: 21),
            ),
            const SizedBox(width: 10),
            const Text('Kindred',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 23)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Search',
            onPressed: () {},
            icon: const Icon(Icons.search_rounded),
          ),
          IconButton(
            tooltip: 'More options',
            onPressed: () {},
            icon: const Icon(Icons.more_vert_rounded),
          ),
        ],
      ),
      body: pages[selectedTab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedTab,
        onDestinationSelected: (index) =>
            setState(() => selectedTab = index),
        backgroundColor: Colors.white,
        indicatorColor: kindredBlue.withOpacity(.12),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.chat_bubble_outline_rounded),
              selectedIcon: Icon(Icons.chat_bubble_rounded),
              label: 'Chats'),
          NavigationDestination(
              icon: Icon(Icons.circle_outlined),
              selectedIcon: Icon(Icons.circle),
              label: 'Status'),
          NavigationDestination(
              icon: Icon(Icons.language_rounded),
              selectedIcon: Icon(Icons.language_rounded),
              label: 'Sites'),
          NavigationDestination(
              icon: Icon(Icons.call_outlined),
              selectedIcon: Icon(Icons.call_rounded),
              label: 'Calls'),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: selectedTab == 1 ? kindredGreen : kindredBlue,
        foregroundColor: Colors.white,
        onPressed: () {},
        child: Icon([
          Icons.edit_rounded,
          Icons.add_a_photo_rounded,
          Icons.add_rounded,
          Icons.add_ic_call_rounded,
        ][selectedTab]),
      ),
    );
  }
}

class ChatsPage extends StatelessWidget {
  const ChatsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final chats = [
      ('Ada', 'Are we still meeting today?', '10:42', 'A', 2),
      ('Family Circle', 'Mum: Thank you everyone ❤️', '09:18', 'F', 4),
      ('Tobi', 'Voice message', 'Yesterday', 'T', 0),
      ('Project Team', 'You: I have shared the update', 'Yesterday', 'P', 0),
    ];
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      children: [
        const Text('Your conversations',
            style: TextStyle(fontSize: 14, color: Colors.black54)),
        const SizedBox(height: 10),
        ...chats.map((chat) => ListTile(
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 4, vertical: 5),
              leading: CircleAvatar(
                radius: 25,
                backgroundColor: kindredBlue.withOpacity(.12),
                child: Text(chat.$4,
                    style: const TextStyle(
                        color: kindredBlue, fontWeight: FontWeight.bold)),
              ),
              title: Text(chat.$1,
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(chat.$2, maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(chat.$3,
                      style:
                          const TextStyle(fontSize: 11, color: Colors.black54)),
                  if (chat.$5 > 0) ...[
                    const SizedBox(height: 5),
                    CircleAvatar(
                      radius: 9,
                      backgroundColor: kindredGreen,
                      child: Text('${chat.$5}',
                          style: const TextStyle(
                              color: Colors.white, fontSize: 10)),
                    )
                  ]
                ],
              ),
              onTap: () {},
            )),
      ],
    );
  }
}

class StatusPage extends StatelessWidget {
  const StatusPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Status',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          ListTile(
            leading: Stack(children: [
              const CircleAvatar(
                  radius: 27,
                  backgroundColor: Color(0xFFE3F2ED),
                  child: Icon(Icons.person, color: kindredGreen)),
              Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    decoration: const BoxDecoration(
                        color: kindredGreen, shape: BoxShape.circle),
                    child: const Icon(Icons.add, color: Colors.white, size: 17),
                  ))
            ]),
            title: const Text('My status',
                style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('Share a photo, video or text update'),
          ),
          const Divider(height: 28),
          const Text('RECENT UPDATES',
              style: TextStyle(
                  color: kindredGreen,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1)),
          const SizedBox(height: 12),
          const Center(
              child: Text('New status updates will appear here.',
                  style: TextStyle(color: Colors.black54))),
        ],
      );
}

class SitesPage extends StatelessWidget {
  const SitesPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Sites',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text('Discover and join spaces around your interests.',
              style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 18),
          _siteCard(Icons.school_rounded, 'Learning Site',
              'Share knowledge and learn together.'),
          _siteCard(Icons.music_note_rounded, 'Music Site',
              'Connect with people who love music.'),
          _siteCard(Icons.location_city_rounded, 'Local Community Site',
              'Find conversations around your area.'),
        ],
      );

  Widget _siteCard(IconData icon, String title, String subtitle) => Card(
        color: Colors.white,
        elevation: 0,
        margin: const EdgeInsets.only(bottom: 12),
        child: ListTile(
          leading: CircleAvatar(
              backgroundColor: kindredGreen.withOpacity(.12),
              child: Icon(icon, color: kindredGreen)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () {},
        ),
      );
}

class CallsPage extends StatelessWidget {
  const CallsPage({super.key});

  @override
  Widget build(BuildContext context) => const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.call_rounded, size: 54, color: kindredBlue),
            SizedBox(height: 12),
            Text('Your calls will appear here',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
            SizedBox(height: 6),
            Text('Voice and video calling will be added in development.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54)),
          ],
        ),
      );
}
